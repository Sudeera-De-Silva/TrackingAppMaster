import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/VehiclesDetailsPage.dart';

class DirectionDetailsScreen extends StatelessWidget {
  const DirectionDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            //To Implement
          ],
        )
        
  const SizedBox(height: 10.0),

      ElevatedButton(
            onPressed: () {
              Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const VehicleDetailsPage()));
            },

                child:const Text('Track Vehicles'),
              ),
      ),
    );
  }
}

