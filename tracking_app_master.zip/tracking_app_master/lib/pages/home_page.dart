import 'package:flutter/material.dart';
import 'package:tracking_app_master/Sub_Pages/DirectionDetails.dart';
import 'package:tracking_app_master/Sub_Pages/FuelDetails.dart';
import 'package:tracking_app_master/Sub_Pages/HistoryDetails.dart';
import 'package:tracking_app_master/Sub_Pages/OtherDetails.dart';
import 'package:tracking_app_master/Sub_Pages/VehicleTrackingScreen.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title:const Text('HomePage!'),
      iconTheme:const IconThemeData(),
      backgroundColor:const Color(Colors.blueAccent)),
      body:Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                'Welcome to Vehicle Tracking App!',
                style: TextStyle(fontSize: 24.0),
              ),
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>const HistoryDetailsScreen()));
                },
                child: const Text('View History'),
              ),
              const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TrackVehiclesScreen()));
                },
                child:const Text('Track Vehicles'),
              ),
              const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FuelDetailsScreen()));
                },
                child: const Text('check Fuel quentity'),
              ),
            const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const DirectionDetailsScreen()));
                },
                child: const Text('Stopping Directions By Driver'),
              ),
              const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>const OtherDetailsScreen()));
                },
                child: const Text('Other Details'),
              ),
            ],
          ),
      ),
      );
   }
 }