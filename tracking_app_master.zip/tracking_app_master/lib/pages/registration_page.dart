import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/home_page.dart';

// ignore: camel_case_types
class Registration_page extends StatelessWidget {
  const Registration_page
({super.key, required Center body});

  @override
  Widget build(BuildContext context) {
    var usernameController;
    var emailController;
    var passwordController;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextFormField(
              controller: usernameController,
              decoration: const InputDecoration(labelText: 'Username'),
            ),

            const SizedBox(height: 20.0),

            TextFormField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),

            const SizedBox(height: 20.0),

            ElevatedButton(
              onPressed: () {
                //  user registration logic here
                String username = usernameController.text;
                String email    = emailController.text;
                String password = passwordController.text;
                // add validation and registration logic here
                Text('Username: $username, Email: $email, Password: $password');
              },
              child: const Text('Register'),
            ),

            const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Homepage()));
                },
                child:const Text('Go To Home Page!'),
              ),

           ],

        ),

      )

    );
  
  }
}